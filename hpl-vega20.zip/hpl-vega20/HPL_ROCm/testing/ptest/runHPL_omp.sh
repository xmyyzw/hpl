#!/bin/bash

num_cpu_cores=14
num_gpus=1

# FOR OMP
export OMP_NUM_THREADS=${num_cpu_cores}
export LD_LIBRARY_PATH=openblas:$LD_LIBRARY_PATH

# ./xhpl
HSA_ENABLE_SDMA=1 mpirun -np ${num_gpus} --map-by numa:PE=${num_cpu_cores} --bind-to core:overload-allowed --report-bindings ./bin/ROCM/xhpl