/*
# Copyright (c) 2008-2011,  NVIDIA CORPORATION
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met: Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution. Neither the name
# of NVIDIA nor the names of its contributors may be used to endorse or
# promote products derived from this software without specific prior written
# permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
# NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/*
  Initial implementation of host library to intercept DGEMM and DTRSM
  and distribute the work between GPU and CPU cores.
  This implementation assumes that each MPI process is going to use a
  single GPU.


  @2008-2009 Massimiliano Fatica
  @2010-2011 Everett Phillips and Massimiliano Fatica

  History:
  04/09/2009	Fixed bug in the sorting of the host names
  12/28/2008	Initial external release

*/
#include "hpl.h"
#include "HPL_gpu.h"

//#define DTRSM_ACCUM_TIMER
//#define DGEMM_ACCUM_TIMER

#ifdef HPL_STDC_HEADERS
void gpu_dtrsm
(
   const enum HPL_ORDER             order,
   const enum HPL_SIDE              side,
   const enum HPL_UPLO              uplo,
   const enum HPL_TRANS             transa,
   const enum HPL_DIAG              diag,
   const int                        m,
   const int                        n,
   const double                     alpha,
   const double *                   A,
   const int                        lda,
   double *                         B,
   const int                        ldb
)
#else
void gpu_dtrsm
( order, side, uplo, transa, diag, m, n, alpha, A, lda, B, ldb )
   const enum HPL_ORDER             order;
   const enum HPL_SIDE              side;
   const enum HPL_UPLO              uplo;
   const enum HPL_TRANS             transa;
   const enum HPL_DIAG              diag;
   const int                        m;
   const int                        n;
   const double                     alpha;
   const double *                   A;
   const int                        lda;
   double *                         B;
   const int                        ldb;
#endif
{
  double *devPtrA, *devPtrB;

  double  time_dtrsm, time_cpu, time_gpu, time_kernel;

  double *dtrsm_scratch[NSTREAMS];

  float eventTimer;
  static int last_k=0;
  int n_gpu, n_cpu;
  int m_gpu, m_cpu;
  static float used_split;
  float ratio;
  int i, iters;

  //quick return
  if (m <= 0 || n <=0) return;

  //convert arguments to hipBlas types
  hipblasSideMode_t side_hip;
  hipblasFillMode_t uplo_hip;
  hipblasOperation_t transa_hip;
  hipblasDiagType_t diag_hip;

  if (side == HplLeft)
    side_hip = HIPBLAS_SIDE_LEFT;
  else if (side == HplRight)
    side_hip = HIPBLAS_SIDE_RIGHT;
  else {
    printf("Invalid side value passed to gpu_dtrsm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  if (uplo == HplUpper)
    uplo_hip = HIPBLAS_FILL_MODE_UPPER;
  else if (uplo == HplLower)
    uplo_hip = HIPBLAS_FILL_MODE_LOWER;
  else {
    printf("Invalid uplo value passed to gpu_dtrsm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  if (transa == HplNoTrans)
    transa_hip = HIPBLAS_OP_N;
  else if (transa == HplTrans)
    transa_hip = HIPBLAS_OP_T;
  else {
    printf("Invalid trans value passed to gpu_dtrsm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  if (diag == HplUnit)
    diag_hip = HIPBLAS_DIAG_UNIT;
  else if (diag == HplNonUnit)
    diag_hip = HIPBLAS_DIAG_NON_UNIT;
  else {
    printf("Invalid diag value passed to gpu_dtrsm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  int k=0;
  if(side == HplLeft) {
    k = m;
  } else {
    k = n;
  }

  if ( k < 512 || dtrsm_split < 0.01 || k>2048) {
    cblas_dtrsm( order, side, uplo, transa, diag, m, n, alpha, A, lda, B, ldb );
    return;
  }

  if(k>last_k+4096 || last_k ==0) {
#ifdef VERBOSE_PRINT
    printf("%d resetting DTRSM SPLIT = %f \n",myrank,dtrsm_split);
#endif
    for(i=0; i<100; i++) dtrsm_splits[i] = dtrsm_split;
  }
  last_k = k;

#ifdef AUTOSPLIT
  int knk = imin(k/NK,99);
  used_split = dtrsm_splits[knk];
#else
  used_split = dtrsm_split;
#endif

  time_dtrsm=wallclock();
  hipSetDevice(mydev);


  hipEventRecord(start);

  //copy A to device (k must not be too large)
  devPtrA = scratch;
  hipMemcpy2DAsync(devPtrA, k*sizeof(double),
                   A, lda*sizeof(double),
                   k*sizeof(double), k,
                   hipMemcpyHostToDevice, streams[0]);
  hipEventRecord(Acopy, streams[0]);

  size_t freeBytes = (scratch_size*NSTREAMS - k*k*sizeof(double))/NSTREAMS;

  //all streams wait for this copy to complete
  for (int s=0;s<NSTREAMS;s++) {
    hipStreamWaitEvent(streams[s],Acopy,0);
    dtrsm_scratch[s] = scratch + k*k + s*(freeBytes/sizeof(double));
  }


  if(side == HplLeft) {

    n_gpu = ceil(n*used_split);
    n_cpu = n - n_gpu;

    int nmax = (freeBytes/(m*sizeof(double)));
    nmax = imin(nmax,CHUNK_SIZE);

    iters= ((n_gpu+nmax-1)/nmax);

    // printf("DTRSM n=%d n_gpu=%d used_split=%f, nmax=%d, iters=%d\n", n, n_gpu, used_split, nmax, iters);

    size_t b_offset_gpu=0;
    for(i=0; i<iters; i++) {

      int s = i%NSTREAMS;

      int nn = imin(nmax,n_gpu-i*nmax);

      devPtrB = dtrsm_scratch[s];
      // if (i>0) hipStreamWaitEvent(streams[s],HToDstop[i-1],0);
      // hipEventRecord(HToDstart[i],streams[s]);
      hipMemcpy2DAsync(devPtrB, m*sizeof(double),
                       B+b_offset_gpu, ldb*sizeof(double),
                       m*sizeof(double), nn,
                       hipMemcpyHostToDevice, streams[s]);
      // hipEventRecord(HToDstop[i],streams[s]);
      HToDbytes[i] = m*sizeof(double)*nn;

      // if (i>0) hipStreamWaitEvent(streams[s],Kernelstop[i-1],0);
      // hipEventRecord(Kernelstart[i],streams[s]);
      checkHipBlasErrors(hipblasDtrsm(hipBlasHandle[s], side_hip,uplo_hip,transa_hip,diag_hip,m,nn,&alpha,devPtrA, m, devPtrB, m));
      // hipEventRecord(Kernelstop[i],streams[s]);

      // if (i>0) hipStreamWaitEvent(streams[s],DToHstop[i-1],0);
      // hipEventRecord(DToHstart[i],streams[s]);
      hipMemcpy2DAsync(B+b_offset_gpu, ldb*sizeof(double),
                       devPtrB, m*sizeof(double),
                       m*sizeof(double), nn,
                       hipMemcpyDeviceToHost, streams[s]);
      // hipEventRecord(DToHstop[i],streams[s]);
      DToHbytes[i] = m*sizeof(double)*nn;

      b_offset_gpu += ((size_t)ldb)*nn;
    }
    hipEventRecord(stop);

    size_t b_offset = ((size_t)ldb)*n_gpu;
    cblas_dtrsm( order, side, uplo, transa, diag, m, n_cpu, alpha, A, lda, B+b_offset, ldb );

  } else {

    m_gpu = ceil(m*used_split);
    m_cpu = m - m_gpu;

    int mmax = (freeBytes/(n*sizeof(double)));
    mmax = imin(mmax,CHUNK_SIZE);

    iters= ((m_gpu+mmax-1)/mmax);

    size_t b_offset_gpu=0;

    for(i=0; i<iters; i++) {

      int s = i%NSTREAMS;
      stream = streams[s];

      int mm = imin(mmax,m_gpu-i*mmax);

      devPtrB = dtrsm_scratch[s];
      hipMemcpy2DAsync(devPtrB, mm*sizeof(double),
                       B+b_offset_gpu, ldb*sizeof(double),
                       mm*sizeof(double), n,
                       hipMemcpyHostToDevice, stream);

      checkHipBlasErrors(hipblasDtrsm(hipBlasHandle[s], side_hip,uplo_hip,transa_hip,diag_hip,mm,n,&alpha,devPtrA, n, devPtrB, mm));

      hipMemcpy2DAsync(B+b_offset_gpu, ldb*sizeof(double),
                       devPtrB, mm*sizeof(double),
                       mm*sizeof(double), n,
                       hipMemcpyDeviceToHost, stream);

      b_offset_gpu += mm;
    }
    hipEventRecord(stop);

    cblas_dtrsm( order, side, uplo, transa, diag, m_cpu, n, alpha, A, lda, B+m_gpu, ldb );
  }

  time_cpu=wallclock()-time_dtrsm;

  hipEventSynchronize(stop);
  hipEventElapsedTime(&eventTimer, start, stop);
  time_gpu = (double)eventTimer/1000.0;

  ratio = time_gpu/time_cpu;

  time_dtrsm=wallclock()-time_dtrsm;
  float new_split = 0.5*(used_split + 1.0/(1.0 + (ratio)*(1.0-used_split)/used_split ));
#ifdef VERBOSE_PRINT
  if(side == HplLeft) {
    printf (" rank:%2d DTRSM m=%5d n=%5d n_split=(%5d %5d) time_split=(%7.3f %7.3f) RATIO: %5.4f USED_SPLIT: %5.3f NEW_SPLIT:%5.3f \n", myrank,m,n, n_cpu,n_gpu, time_cpu, time_gpu, ratio, used_split, new_split);
  } else {
    printf (" rank:%2d DTRSM m=%5d n=%5d m_split=(%5d %5d) time_split=(%7.3f %7.3f) RATIO: %5.4f USED_SPLIT: %5.3f NEW_SPLIT:%5.3f \n", myrank,m,n, m_cpu,m_gpu, time_cpu, time_gpu, ratio, used_split, new_split);
  }
#endif

#ifdef AUTOSPLIT
  dtrsm_splits[knk] = new_split;
#else
  used_split = new_split;
#endif
  hipDeviceSynchronize();
}


/**
 * end of gpu_dtrsm
 */



/**
 * begin of gpu_dgemm
 */

#ifdef HPL_STDC_HEADERS
void gpu_dgemm
(
   const enum HPL_ORDER             order,
   const enum HPL_TRANS             transa,
   const enum HPL_TRANS             transb,
   const int                        m,
   const int                        n,
   const int                        k,
   const double                     alpha,
   const double *                   A,
   const int                        lda,
   const double *                   B,
   const int                        ldb,
   const double                     beta,
   double *                         C,
   const int                        ldc
)
#else
void gpu_dgemm
( order, transa, transb, m, n, k, alpha, A, lda, B, ldb, beta, C, ldc )
   const enum HPL_ORDER             order;
   const enum HPL_TRANS             transa;
   const enum HPL_TRANS             transb;
   const int                        m;
   const int                        n;
   const int                        k;
   const double                     alpha;
   const double *                   A;
   const int                        lda;
   const double *                   B;
   const int                        ldb;
   const double                     beta;
   double *                         C;
   const int                        ldc;
#endif
{
  int m_gpu, n_gpu, k_gpu, m_cpu2, n_cpu2, opt_M;
  int m_cpu, n_cpu, k_cpu;
  int nmax, mmax, nmax1, mmax1, iter, j, outer_iter, last_iter;
  int nn, mm;
  int i;
  size_t a_offset, b_offset, c_offset;
  size_t a_offset_gpu, b_offset_gpu, c_offset_gpu;
  size_t b_offset_gpu1, c_offset_gpu1;
  size_t b_offset_gpu2, c_offset_gpu2;
  size_t b_offset_gpu3, c_offset_gpu3;
  double *devPtrA, *devPtrB, *devPtrC;
  double CPU_GFLOPS,GPU_GFLOPS,GFLOPS;
  static int last_m=0, last_n=0;
  float used_split=0.7, opt_split, ratio;

  double  time_dgemm, time_gpu;
  double  time_cpu, time_kernel;

  float eventTimer;

  static int first_split;
  static int counter=0;

  if( (m==0) || (n==0) || (k==0) ) return;

  if ( (n) < 256 || (m) <256 || (k) <256 ) {

    cblas_dgemm( order, transa, transb, m, n, k, alpha, A, lda, B, ldb,
                beta, C, ldc );
    return;
  }

  //convert arguments to hipBlas types
  hipblasOperation_t transa_hip, transb_hip;

  if (transa == HplNoTrans)
    transa_hip = HIPBLAS_OP_N;
  else if (transa == HplTrans)
    transa_hip = HIPBLAS_OP_T;
  else {
    printf("Invalid trans value passed to gpu_dgemm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  if (transb == HplNoTrans)
    transb_hip = HIPBLAS_OP_N;
  else if (transb == HplTrans)
    transb_hip = HIPBLAS_OP_T;
  else {
    printf("Invalid trans value passed to gpu_dgemm\n");
    MPI_Abort(MPI_COMM_WORLD, 0);
  }

  if (m >= n) {
    //split along m
    if(m > last_m+4096 || last_m ==0) {
#ifdef VERBOSE_PRINT
      printf("RESETTING SPLITS TO %f \n",dgemm_split);
#endif
      for(i=0; i<100; i++) dgemm_splits[i] = dgemm_split;
      first_split = 1;
    }
    last_m = m;

#ifdef AUTOSPLIT2
    int knk = imin(k/NK,99);
    used_split = dgemm_splits[knk];
#else
    used_split = dgemm_split;
#endif

    hipSetDevice(mydev);

    time_dgemm=wallclock();

    hipEventRecord(start);

    // m_gpu = imin(ceil(m /opt_M*(used_split))*opt_M,m-m%opt_M);
    m_gpu = ceil(m*used_split);
    m_cpu = m-m_gpu;

    if(transa==HplNoTrans)
      a_offset = m_gpu;
    else
      a_offset = ((size_t)m_gpu)*lda;

    b_offset = 0;
    c_offset = m_gpu;
    a_offset_gpu = 0;
    b_offset_gpu = 0;
    c_offset_gpu = 0;

    //estimate for how large a dgemm can fit on device. Total memory is (k*mmax + mmax*k + mmax*mmax) doubles
    //  printf("scratch_size = %ld MB, or %ld doubles\n", scratch_size>>20, scratch_size/sizeof(double));
    int mmax = ((sqrt(k*k + floor(scratch_size/sizeof(double)))-k));
    // int mmax = 500;

    if (mmax>n) { //if n is small we can fit a bigger slice
      //total memory is (k*mmax + k*n + n*mmax)
      mmax = (scratch_size/sizeof(double) - k*n)/((double)(k+n));
    }

    mmax = imin(mmax,CHUNK_SIZE);

    int iter_m = (m_gpu+mmax-1)/mmax;
    int iter_n = (n    +mmax-1)/mmax;

    // printf("Rank %d m=%d n=%d k=%d, mmax=%d iters_m=%d iters_n=%d \n", myrank, m, n, k, mmax, iter_m, iter_n);
    i=0;
    for (int im=0; im<iter_m;im++) {

      b_offset_gpu = 0;
      c_offset_gpu = im*mmax;

      for (int in=0; in<iter_n;in++) {

        int s = (in+im*iter_n)%NSTREAMS;
        stream = streams[s];

        int lda_gpu=0;
        int ldb_gpu=0;
        int ldc_gpu=0;

        mm = imin(mmax, m_gpu-im*mmax);
        nn = imin(mmax, n-in*mmax);

        devPtrA = dev_scratch[s];
        // if (i>0) hipStreamWaitEvent(streams[s],HToDstop[i-1],0);
        // hipEventRecord(HToDstart[i],streams[s]);
        if(transa==HplNoTrans) {
          lda_gpu = mm;
          hipMemcpy2DAsync(devPtrA, lda_gpu*sizeof(double),
                         A+a_offset_gpu, lda*sizeof(double),
                         mm*sizeof(double), k,
                         hipMemcpyHostToDevice, stream);
          // a_offset_gpu += mm;
        } else {
          lda_gpu = k;
          hipMemcpy2DAsync(devPtrA, lda_gpu*sizeof(double),
                         A+a_offset_gpu, lda*sizeof(double),
                         k*sizeof(double), mm,
                         hipMemcpyHostToDevice, stream);
          // a_offset_gpu += mm*lda;
        }


        devPtrB = devPtrA + mm*k;
        if(transb==HplNoTrans) {
          ldb_gpu = k;
          hipMemcpy2DAsync(devPtrB, ldb_gpu*sizeof(double),
                           B+b_offset_gpu, ldb*sizeof(double),
                           k*sizeof(double), nn,
                           hipMemcpyHostToDevice, stream);
          b_offset_gpu += ((size_t)nn)*ldb;
        } else {
          ldb_gpu = nn;
          hipMemcpy2DAsync(devPtrB, ldb_gpu*sizeof(double),
                           B+b_offset_gpu, ldb*sizeof(double),
                           nn*sizeof(double), k,
                           hipMemcpyHostToDevice, stream);
          b_offset_gpu += nn;
        }

        ldc_gpu = mm;
        devPtrC = devPtrB + nn*k;
        hipMemcpy2DAsync(devPtrC, mm*sizeof(double),
                       C+c_offset_gpu, ldc*sizeof(double),
                       mm*sizeof(double), nn,
                       hipMemcpyHostToDevice, stream);
        // hipEventRecord(HToDstop[i],streams[s]);

        // if (i>0) hipStreamWaitEvent(streams[s],Kernelstop[i-1],0);
        // hipEventRecord(Kernelstart[i],streams[s]);
        // printf("Rank %d Queuing DGEMM with m=%d n=%d k=%d, used storage = %ld MB \n", myrank, mm, nn, k, ((mm*k+nn*k+mm*nn)*sizeof(double))/(1024*1024));
        checkHipBlasErrors(hipblasDgemm(hipBlasHandle[s], transa_hip, transb_hip,
                                        mm, nn, k, &alpha, devPtrA, lda_gpu,
                                        devPtrB, ldb_gpu, &beta, devPtrC, ldc_gpu));
        // hipEventRecord(Kernelstop[i],streams[s]);

        if (i>0) hipStreamWaitEvent(streams[s],DToHstop[i-1],0);
        // hipEventRecord(DToHstart[i],streams[s]);
        hipMemcpy2DAsync(C+c_offset_gpu, ldc*sizeof(double),
                         devPtrC, mm*sizeof(double),
                         mm*sizeof(double), nn,
                         hipMemcpyDeviceToHost, stream);
        // hipEventRecord(DToHstop[i],streams[s]);
        c_offset_gpu += ((size_t)nn)*ldc;
        i++;
      }
      if(transa==HplNoTrans) {
        a_offset_gpu += mm;
      } else {
        a_offset_gpu += ((size_t)mm)*lda;
      }
    }

    hipEventRecord(stop);

    cblas_dgemm( order, transa, transb, m_cpu, n, k, alpha,
                A+a_offset, lda, B+b_offset, ldb,
                beta, C+c_offset, ldc );

    time_cpu=wallclock()-time_dgemm;

    hipEventSynchronize(stop);
    hipEventElapsedTime(&eventTimer, start, stop);
    time_gpu = (double)eventTimer/1000.0;

    time_dgemm=wallclock()-time_dgemm;

    ratio = (time_gpu)/time_cpu;
    CPU_GFLOPS = 2.e-9*((double)(m_cpu)*(double)(n)*(double)(k))/time_cpu;
    GPU_GFLOPS = 2.e-9*((double)(m_gpu)*(double)(n)*(double)(k))/time_gpu;

    GFLOPS = 2.e-9*(double)(m) *(double)(n)*(double)(k)/time_dgemm;
    opt_split = GPU_GFLOPS/(GPU_GFLOPS+CPU_GFLOPS);
#ifdef VERBOSE_PRINT
    printf ("rank:%2d  m=%5d n=%5d k=%5d m_split=(%5d %5d) time_split=(%7.3f %7.3f) RATIO: %5.4f (%4.1f CPU + %6.1f GPU = %6.1f GFLOPS)  USED_SPLIT: %5.3f OPT_SPLIT:%5.3f \n", myrank,m,n,k, m_cpu,m_gpu, time_cpu, time_gpu, ratio, CPU_GFLOPS, GPU_GFLOPS, GFLOPS, used_split, opt_split);
#endif

#ifdef AUTOSPLIT
    knk = imin(k/NK,99);
    if(first_split)
    {
      dgemm_splits[knk] = opt_split+0.001;
      first_split=0;
    }

    if(used_split>opt_split) opt_split = 0.5*used_split + 0.5*opt_split;

    if(opt_split > 0.98) opt_split = 0.98;
    if(opt_split < 0.10) opt_split = 0.10;
    dgemm_splits[knk] = opt_split;
#endif

  } else {
    //split along n
    if(n > last_n+4096 || last_n ==0) {
#ifdef VERBOSE_PRINT
      printf("RESETTING SPLITS TO %f \n",dgemm_split);
#endif
      for(i=0; i<100; i++) dgemm_splits[i] = dgemm_split;
      first_split = 1;
    }
    last_n = n;

#ifdef AUTOSPLIT2
    int knk = imin(k/NK,99);
    used_split = dgemm_splits[knk];
#else
    used_split = dgemm_split;
#endif

    hipSetDevice(mydev);

    time_dgemm=wallclock();

    hipEventRecord(start);

    // m_gpu = imin(ceil(m /opt_M*(used_split))*opt_M,m-m%opt_M);
    n_gpu = ceil(n*used_split);
    n_cpu = n-n_gpu;

    if(transb==HplNoTrans)
      b_offset = ((size_t)n_gpu)*ldb;
    else
      b_offset = n_gpu;

    a_offset = 0;
    c_offset = ((size_t)n_gpu)*ldc;
    a_offset_gpu = 0;
    b_offset_gpu = 0;
    c_offset_gpu = 0;

    //estimate for how large a dgemm can fit on device. Total memory is (k*mmax + mmax*k + mmax*mmax) doubles
    // int nmax = sqrt(k*k + floor(scratch_size/sizeof(double)))-k;

    //  printf("scratch_size = %ld MB, or %ld doubles\n", scratch_size>>20, scratch_size/sizeof(double));
    int nmax = ((sqrt(k*k + floor(scratch_size/sizeof(double)))-k));

    if (nmax>m) { //if m is small we can fit a bigger slice
      //total memory is (k*nmax + k*m + m*nmax)
      nmax = (scratch_size/sizeof(double) - k*m)/((double)(k+m));
    }

    nmax = imin(nmax,CHUNK_SIZE);

    int iter_m = (m    +nmax-1)/nmax;
    int iter_n = (n_gpu+nmax-1)/nmax;

    // printf("Rank %d m=%d n=%d k=%d, nmax=%d iters_m=%d iters_n=%d \n", myrank, m, n, k, nmax, iter_m, iter_n);
    i=0;
    for (int in=0; in<iter_n;in++) {

      a_offset_gpu = 0;
      c_offset_gpu = in*nmax*((size_t)ldc);

      for (int im=0; im<iter_m;im++) {

        int s = (im+in*iter_m)%NSTREAMS;
        stream = streams[s];

        int lda_gpu=0;
        int ldb_gpu=0;
        int ldc_gpu=0;

        nn = imin(nmax, n_gpu-in*nmax);
        mm = imin(nmax, m-im*nmax);

        devPtrB = dev_scratch[s];
        // if (i>0) hipStreamWaitEvent(streams[s],HToDstop[i-1],0);
        // printf("i = %d, s=%d\n", i, s);
        // hipEventRecord(HToDstart[i],streams[s]);
        if(transb==HplNoTrans) {
          ldb_gpu = k;
          hipMemcpy2DAsync(devPtrB, ldb_gpu*sizeof(double),
                           B+b_offset_gpu, ldb*sizeof(double),
                           k*sizeof(double), nn,
                           hipMemcpyHostToDevice, stream);
          // b_offset_gpu += nn*ldb;
        } else {
          ldb_gpu = nn;
          hipMemcpy2DAsync(devPtrB, ldb_gpu*sizeof(double),
                           B+b_offset_gpu, ldb*sizeof(double),
                           nn*sizeof(double), k,
                           hipMemcpyHostToDevice, stream);
          // b_offset_gpu += nn;
        }

        devPtrA = devPtrB + nn*k;
        if(transa==HplNoTrans) {
          lda_gpu = mm;
          hipMemcpy2DAsync(devPtrA, lda_gpu*sizeof(double),
                         A+a_offset_gpu, lda*sizeof(double),
                         mm*sizeof(double), k,
                         hipMemcpyHostToDevice, stream);
          a_offset_gpu += mm;
        } else {
          lda_gpu = k;
          hipMemcpy2DAsync(devPtrA, lda_gpu*sizeof(double),
                         A+a_offset_gpu, lda*sizeof(double),
                         k*sizeof(double), mm,
                         hipMemcpyHostToDevice, stream);
          a_offset_gpu += ((size_t)mm)*lda;
        }

        ldc_gpu = mm;
        devPtrC = devPtrA + mm*k;
        hipMemcpy2DAsync(devPtrC, mm*sizeof(double),
                       C+c_offset_gpu, ldc*sizeof(double),
                       mm*sizeof(double), nn,
                       hipMemcpyHostToDevice, stream);
        // hipEventRecord(HToDstop[i],streams[s]);

        // if (i>0) hipStreamWaitEvent(streams[s],Kernelstop[i-1],0);
        // hipEventRecord(Kernelstart[i],streams[s]);
        // printf("Rank %d Queuing DGEMM with m=%d n=%d k=%d, used storage = %ld MB \n", myrank, mm, nn, k, ((nn*k+mm*k+nn*mm)*sizeof(double))/(1024*1024));
        checkHipBlasErrors(hipblasDgemm(hipBlasHandle[s], transa_hip, transb_hip, mm, nn, k, &alpha, devPtrA, lda_gpu,
                                        devPtrB, ldb_gpu, &beta, devPtrC, ldc_gpu));
        // hipEventRecord(Kernelstop[i],streams[s]);

        // if (i>0) hipStreamWaitEvent(streams[s],DToHstop[i-1],0);
        // hipEventRecord(DToHstart[i],streams[s]);
        hipMemcpy2DAsync(C+c_offset_gpu, ldc*sizeof(double),
                         devPtrC, mm*sizeof(double),
                         mm*sizeof(double), nn,
                         hipMemcpyDeviceToHost, stream);
        // hipEventRecord(DToHstop[i],streams[s]);
        c_offset_gpu += mm;
        i++;
      }
      if(transb==HplNoTrans) {
        b_offset_gpu += ((size_t)nn)*ldb;
      } else {
        b_offset_gpu += nn;
      }
    }

    hipEventRecord(stop);

    cblas_dgemm( order, transa, transb, m, n_cpu, k, alpha,
                A+a_offset, lda, B+b_offset, ldb,
                beta, C+c_offset, ldc );

    time_cpu=wallclock()-time_dgemm;

    hipEventSynchronize(stop);

    hipEventElapsedTime(&eventTimer, start, stop);
    time_gpu = (double)eventTimer/1000.0;

    time_dgemm=wallclock()-time_dgemm;

    ratio = (time_gpu)/time_cpu;
    CPU_GFLOPS = 2.e-9*((double)(m)*(double)(n_cpu)*(double)(k))/time_cpu;
    GPU_GFLOPS = 2.e-9*((double)(m)*(double)(n_gpu)*(double)(k))/time_gpu;

    GFLOPS = 2.e-9*(double)(m) *(double)(n)*(double)(k)/time_dgemm;
    opt_split = GPU_GFLOPS/(GPU_GFLOPS+CPU_GFLOPS);
#ifdef VERBOSE_PRINT
    printf ("rank:%2d  m=%5d n=%5d k=%5d n_split=(%5d %5d) time_split=(%7.3f %7.3f) RATIO: %5.4f (%4.1f CPU + %6.1f GPU = %6.1f GFLOPS)  USED_SPLIT: %5.3f OPT_SPLIT:%5.3f \n", myrank,m,n,k, n_cpu,n_gpu, time_cpu, time_gpu, ratio, CPU_GFLOPS, GPU_GFLOPS, GFLOPS, used_split, opt_split);
#endif

#ifdef AUTOSPLIT
    knk = imin(k/NK,99);
    if(first_split)
    {
      dgemm_splits[knk] = opt_split+0.001;
      dgemm_split = opt_split+0.001;
      first_split=0;
    }

    if(used_split>opt_split) opt_split = 0.5*used_split + 0.5*opt_split;

    if(opt_split > 0.98) opt_split = 0.98;
    if(opt_split < 0.10) opt_split = 0.10;
    dgemm_splits[knk] = opt_split;
#endif
  }
  hipDeviceSynchronize();
}

/**
 * end of gpu_dgemm
 */
