/*
# Copyright (c) 2008-2011,  NVIDIA CORPORATION
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met: Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution. Neither the name
# of NVIDIA nor the names of its contributors may be used to endorse or
# promote products derived from this software without specific prior written
# permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
# NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/*
  Initial implementation of host library to intercept DGEMM and DTRSM
  and distribute the work between GPU and CPU cores.
  This implementation assumes that each MPI process is going to use a
  single GPU.


  @2008-2009 Massimiliano Fatica
  @2010-2011 Everett Phillips and Massimiliano Fatica

  History:
  04/09/2009	Fixed bug in the sorting of the host names
  12/28/2008	Initial external release

*/
#include "hpl.h"
#include "HPL_gpu.h"


/*define scratch arrays on GPU */
double *scratch;
double *dev_scratch[NSTREAMS];
size_t scratch_size;
hipblasHandle_t hipBlasHandle[NSTREAMS];

/*
  The first time DGEMM or DTRSM are called, the library needs to map a GPU to the MPI process.
  This variable checks if this step has already been performed
*/
int myrank=0;
int mydev;

hipEvent_t start, stop;
hipEvent_t Acopy;

hipEvent_t HToDstart[4000], HToDstop[4000];
hipEvent_t Kernelstart[4000], Kernelstop[4000];
hipEvent_t DToHstart[4000], DToHstop[4000];

size_t HToDbytes[4000];
size_t kernelflops[4000];
size_t DToHbytes[4000];

float dtrsm_split=0.70;
float dgemm_split=0.85;
float *dgemm_splits,*dtrsm_splits;

hipStream_t streams[NSTREAMS];
hipStream_t stream;

int stringCmp( const void *a, const void *b)
{
  char *c_a = (char*) a;
  char *c_b = (char*) b;
  return strcmp(c_a,c_b);
}

static char     host_name[MPI_MAX_PROCESSOR_NAME];


double wallclock(void)
{
  struct timeval tv;
  struct timezone tz;
  double t;

  gettimeofday(&tv, &tz);

  t = (double)tv.tv_sec;
  t += ((double)tv.tv_usec)/1000000.0;

  return t;
}

/*
  This function finds out how many MPI processes are running on the same node
  and assigns a local rank that can be used to map a process to a device.
  This function needs to be called by all the MPI processes.
*/
void  Init_gpu(){

  char (*host_names)[MPI_MAX_PROCESSOR_NAME];
  MPI_Comm nodeComm;

  int i, n, namelen, color, rank, nprocs;
  size_t bytes;
  int dev;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
  MPI_Get_processor_name(host_name,&namelen);

  bytes = nprocs * sizeof(char[MPI_MAX_PROCESSOR_NAME]);
  host_names = (char (*)[MPI_MAX_PROCESSOR_NAME]) malloc(bytes);

  strcpy(host_names[rank], host_name);

  for (n=0; n<nprocs; n++){
    MPI_Bcast(&(host_names[n]),MPI_MAX_PROCESSOR_NAME, MPI_CHAR, n, MPI_COMM_WORLD);
  }

  int localRank = 0;
  for (n=0; n<rank; n++){
    if (!strcmp(host_name, host_names[n])) localRank++;
  }

  int localSize = 0;
  for (n=0; n<nprocs; n++){
    if (!strcmp(host_name, host_names[n])) localSize++;
  }

  /* Find out how many DP capable GPUs are in the system and their device number */
  hipInit(0);

  int deviceCount;
  hipGetDeviceCount(&deviceCount);

#ifdef VERBOSE_PRINT
  printf ("Assigning device %d on node %s to rank %d \n", localRank%deviceCount,  host_name, rank);
#endif

  /* Assign device to MPI process, initialize BLAS and probe device properties */
  mydev = localRank%deviceCount;
  hipSetDevice(mydev);


  for(int i = 0; i < NSTREAMS; i++) {
    hipblasCreate(hipBlasHandle+i);
  }

  hipGetDevice(&dev);

  size_t free_bytes, total_bytes;
  hipMemGetInfo(&free_bytes, &total_bytes);

  //round to nearest MB
  deviceCount = imin(deviceCount, localSize);

  scratch_size = 4*NSTREAMS*CHUNK_SIZE*CHUNK_SIZE*sizeof(double);

  //scratch_size = (size_t) (0.5*((free_bytes*deviceCount/(NSTREAMS*localSize))>>20)*1024*1024);

#ifdef VERBOSE_PRINT
  printf("rank %d Allocating scratch buffer: %lld MB\n",rank,(scratch_size*NSTREAMS)>>20);
#endif

  checkHipErrors(hipMalloc(&scratch, scratch_size*NSTREAMS));

  for(int i = 0; i < NSTREAMS; i++) {
    dev_scratch[i] = scratch + i*(scratch_size/sizeof(double));

    checkHipErrors(hipStreamCreate(streams+i));
    hipblasSetStream(hipBlasHandle[i], streams[i]);
  }

  hipEventCreate(&start);
  hipEventCreate(&stop);
  hipEventCreate(&Acopy);

  for (int i=0;i<4000;i++) {
    hipEventCreate(HToDstart+i); hipEventCreate(HToDstop+i);
    hipEventCreate(Kernelstart+i); hipEventCreate(Kernelstop+i);
    hipEventCreate(DToHstart+i); hipEventCreate(DToHstop+i);
  }

  myrank = rank;

  /*Check if environment variable HIP_DTRSM_SPLIT is set, otherwise use standard split */
  const char *name2= "HIP_DTRSM_SPLIT";
  char *value2;
  value2 = getenv(name2);
  if (value2 != NULL ){
    dtrsm_split = atof(value2);
#ifdef VERBOSE_PRINT
    printf ("%d DTRSM split from environment variable %f \n",myrank,dtrsm_split);
#endif
  }

  /*Check if environment variable HIP_DGEMM_SPLIT is set, otherwise use standard dgemm_split */
  const char *name= "HIP_DGEMM_SPLIT";
  char *value;
  value = getenv(name);
  if (value != NULL ){
    dgemm_split = atof(value);
#ifdef VERBOSE_PRINT
    printf ("%d DGEMM dgemm_split from environment variable %f \n",myrank,dgemm_split);
#endif
  }

  dgemm_splits = (float*)malloc(100*sizeof(float));
  if(!dgemm_splits) printf("SPLITS ALLOCATION FAILED on node %s rank %d \n",host_name,myrank);
  for(i=0; i<100; i++) dgemm_splits[i] = dgemm_split;

  dtrsm_splits = (float*)malloc(100*sizeof(float));
  if(!dtrsm_splits) printf("SPLITS ALLOCATION FAILED on node %s rank %d \n",host_name,myrank);
  for(i=0; i<100; i++) dtrsm_splits[i] = dtrsm_split;
}


void  Free_gpu(){

  for(int i = 0; i < NSTREAMS; i++) {
    hipblasDestroy(hipBlasHandle[i]);
  }

  checkHipErrors(hipFree(scratch));

  for(int i = 0; i < NSTREAMS; i++) {
    checkHipErrors(hipStreamDestroy(streams[i]));
  }

  free(dgemm_splits);
  free(dtrsm_splits);
}
