#include "hpl.h"

#ifdef ROCM
rocblas_handle handle;

/*
  The first time DGEMM or DTRSM are called, the library needs to map a GPU to the MPI process.
  This variable checks if this step has already been performed
*/
hipStream_t dataStream[NUM_DC];


hipEvent_t panelUpdate;
hipEvent_t panelCopy;

hipEvent_t panelCopy1;
hipEvent_t panelCopy2;

#ifdef HPL_MODIFIED_MULTI_UPDATE_STREAM
rocblas_handle updateHandle[NUM_UPDATE];
hipStream_t updateStream[NUM_UPDATE];

hipEvent_t dlaswpStart[NUM_COUNT], dlaswpStop[NUM_COUNT];
hipEvent_t dtrsmStart[NUM_COUNT], dtrsmStop[NUM_COUNT];
hipEvent_t dgemmStart[NUM_COUNT], dgemmStop[NUM_COUNT];
#else
hipEvent_t dlaswpStart, dlaswpStop;
hipEvent_t dtrsmStart, dtrsmStop;
hipEvent_t dgemmStart, dgemmStop;
#endif

int stringCmp( const void *a, const void *b)
{
  char *c_a = (char*) a;
  char *c_b = (char*) b;
  return strcmp(c_a,c_b);
}

static char     host_name[MPI_MAX_PROCESSOR_NAME];

/*
  This function finds out how many MPI processes are running on the same node
  and assigns a local rank that can be used to map a process to a device.
  This function needs to be called by all the MPI processes.
*/
void  HPL_InitGPU(){
#ifdef ROCM
  char (*host_names)[MPI_MAX_PROCESSOR_NAME];

//  int i,color;
  int  n, namelen;
  size_t bytes;
  int dev;

  MPI_Get_processor_name(host_name,&namelen);

  bytes = size * sizeof(char[MPI_MAX_PROCESSOR_NAME]);
  host_names = (char (*)[MPI_MAX_PROCESSOR_NAME]) malloc(bytes);

  strcpy(host_names[rank], host_name);

  for (n=0; n<size; n++){
    MPI_Bcast(&(host_names[n]),MPI_MAX_PROCESSOR_NAME, MPI_CHAR, n, MPI_COMM_WORLD);
  }

  int localRank = 0;
  for (n=0; n<rank; n++){
    if (!strcmp(host_name, host_names[n])) localRank++;
  }

  int localSize = 0;
  for (n=0; n<size; n++){
    if (!strcmp(host_name, host_names[n])) localSize++;
  }

  /* Find out how many DP capable GPUs are in the system and their device number */
  hipInit(0);

  int deviceCount;
  hipGetDeviceCount(&deviceCount);

#ifdef VERBOSE_PRINT
  printf ("Assigning device %d on node %s to rank %d \n", localRank%deviceCount,  host_name, rank);
#endif

  /* Assign device to MPI process, initialize BLAS and probe device properties */
  dev = localRank%deviceCount;
  hipSetDevice(dev);

  rocblas_create_handle(&handle);
  //Indicates the pointer is device pointer or host pointer.
  rocblas_set_pointer_mode(handle, rocblas_pointer_mode_host);

#ifdef HPL_MODIFIED_MULTI_UPDATE_STREAM
    for (int j = 0; j < NUM_UPDATE; ++j) {
        rocblas_create_handle(updateHandle+j);
        rocblas_set_pointer_mode(updateHandle[j], rocblas_pointer_mode_host);
        hipStreamCreate(updateStream+j);
        rocblas_set_stream(updateHandle[j],updateStream[j]);
    }
#endif

	for (int j = 0; j < NUM_DC; ++j) {
		hipStreamCreate(&dataStream+j);
		rocblas_set_stream(handle, dataStream[j]);
	}

  hipEventCreate(&panelUpdate);
  hipEventCreate(&panelCopy);
#ifdef HPL_MODIFIED_MULTI_UPDATE_STREAM
    hipEventCreate(&panelCopy1);
    hipEventCreate(&panelCopy2);

    for (int i = 0; i < NUM_COUNT; ++i) {
        hipEventCreate(dlaswpStart+i);
        hipEventCreate(dlaswpStop+i);
        hipEventCreate(dtrsmStart+i);
        hipEventCreate(dtrsmStop+i);
        hipEventCreate(dgemmStart+i);
        hipEventCreate(dgemmStop+i);
    }
#else
  hipEventCreate(&dlaswpStart);
  hipEventCreate(&dlaswpStop);
  hipEventCreate(&dtrsmStart);
  hipEventCreate(&dtrsmStop);
  hipEventCreate(&dgemmStart);
  hipEventCreate(&dgemmStop);
#endif
#endif
}


void  Free_gpu(){
#ifdef ROCM
  rocblas_destroy_handle(handle);

#ifdef HPL_MODIFIED_MULTI_UPDATE_STREAM
    for (int i = 0; i < NUM_UPDATE; ++i) {
        rocblas_destroy_handle(updateHandle[i]);
        hipStreamDestroy(updateStream[i]);
    }
#endif

	for (int i = 0; i < NUM_DC; ++i) {
		hipStreamDestroy(dataStream[i]);
	}

#endif
}

#endif