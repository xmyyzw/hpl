#!/bin/bash

# FOR OMP
export OMP_NUM_THREADS=8
# export BLIS_NUM_THREADS=8

# default 0.75
export HIP_DGEMM_SPLIT=0.70

# default 0.7
export HIP_DTRSM_SPLIT=0.80

# export LD_LIBRARY_PATH=~/openblas:$LD_LIBRARY_PATH
# export LD_LIBRARY_PATH=~/amd-blis-mt-1.2/lib:$LD_LIBRARY_PATH

# ./hpcc
HSA_ENABLE_SDMA=1 mpiexec -np 2 ./hpcc
