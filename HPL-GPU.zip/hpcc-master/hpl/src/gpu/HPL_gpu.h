/*
# Copyright (c) 2008-2011,  NVIDIA CORPORATION
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met: Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
# Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution. Neither the name
# of NVIDIA nor the names of its contributors may be used to endorse or
# promote products derived from this software without specific prior written
# permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
# NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
# TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/


/*
  Initial implementation of host library to intercept DGEMM and DTRSM
  and distribute the work between GPU and CPU cores.
  This implementation assumes that each MPI process is going to use a
  single GPU.


  @2008-2009 Massimiliano Fatica
  @2010-2011 Everett Phillips and Massimiliano Fatica

  History:
  04/09/2009	Fixed bug in the sorting of the host names
  12/28/2008	Initial external release

*/
#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <dlfcn.h>
#include <math.h>

#include <time.h>
#include <sys/types.h>
#include <sys/times.h>
#include <sys/time.h>

#include "hipblas.h"
#include "helper_hip.h"

#define NSTREAMS 4

#define CHUNK_SIZE 4096

//automatically adjust DGEMM dgemm_split (big DGEMMs - update)
#define AUTOSPLIT

//automatically adjust DGEMM dgemm_split (small DGEMMs - panel factorization)
#define AUTOSPLIT2

//interleave streams
//enabled : copy1 copy2 copy3 ... kernel1 kernel2 kernel3 ...
//disabled: copy1 kernel1 copy2 kernel2 copy3 kernel3 ...
// #define INTERLEAVE

#define NK (64)
#define NN (64)
#define NM (64)

#define imin(a,b) (((a)<(b))?(a):(b))
#define imax(a,b) (((a)<(b))?(b):(a))

/*define scratch arrays on GPU */
extern double *scratch;
extern double *dev_scratch[NSTREAMS];
extern size_t scratch_size;
extern hipStream_t streams[NSTREAMS];
extern hipStream_t stream;
extern hipblasHandle_t hipBlasHandle[NSTREAMS];

/*
  The first time DGEMM or DTRSM are called, the library needs to map a GPU to the MPI process.
  This variable checks if this step has already been performed
*/
extern int myrank;
extern int mydev;

extern hipEvent_t start, stop;
extern hipEvent_t Acopy;

extern hipEvent_t HToDstart[4000], HToDstop[4000];
extern hipEvent_t Kernelstart[4000], Kernelstop[4000];
extern hipEvent_t DToHstart[4000], DToHstop[4000];

extern size_t HToDbytes[4000];
extern size_t kernelflops[4000];
extern size_t DToHbytes[4000];

extern float dtrsm_split;
extern float dgemm_split;
extern float *dgemm_splits;
extern float *dtrsm_splits;

double wallclock(void);

/*
  This function finds out how many MPI processes are running on the same node
  and assigns a local rank that can be used to map a process to a device.
  This function needs to be called by all the MPI processes.
*/
void  Init_gpu();

